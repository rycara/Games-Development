var mainState = {
	
	preload: function(){
	game.load.image('player', 'img/bat-20.png'); 
	game.load.image('wallV', 'img/wallVertical.png');
	game.load.image('wallH', 'img/wallHorizontal.png');
	game.load.image('coin', 'img/coin.png');
	game.load.image('wallVb', 'img/wallVertical-black.png');
	game.load.image('wallHb', 'img/wallHorizontal-black.png');
	game.load.image('wallVb', 'img/wallVertical-black.png');
	game.load.image('wallHb', 'img/wallHorizontal-black.png');
	game.load.image('wallH1', 'img/wallHorizontal1.png');	
	game.load.image('button-pause', 'img/button-pause.png');
	game.load.image('enemy', 'img/enemy.png');
	//game.load.spritesheet('button-audio', 'img/button-audio.png', 35, 35);

	game.load.audio('audio-jump', ['audio/jump.ogg', 'audio/jump.mp3', 'audio/jump.m4a']);
	game.load.audio('music', ['audio/music.mp3']);
	game.load.audio('audio-coin', ['audio/coin.mp3']);
	
	},
	createWorld: function(){
	this.walls = game.add.group();
	this.walls.enableBody = true;

	    game.add.sprite(250,-100,'wallVb',0,this.walls);//midBlack
	    game.add.sprite(490,150,'wallVb',0,this.walls);//rightBlack		
	    game.add.sprite(490,-10,'wallVb',0,this.walls);//rightTopBlack	
	    game.add.sprite(-15,-250,'wallVb',0,this.walls);//leftBottomBlack						
		game.add.sprite(5,-11,'wallHb',0,this.walls);//topLeft
		game.add.sprite(300,150,'wallH1',0,this.walls);//topRight
		game.add.sprite(0,320,'wallH1',0,this.walls);//bottomLeft
		game.add.sprite(300,320,'wallH1',0,this.walls);//bottomRight
		
		game.add.sprite(-100,160,'wallH1',0,this.walls);//midLeft
		
		var middleRight = game.add.sprite(260, 230, 'wallH',0,this.walls);
		middleRight.scale.setTo(0.7,1);//middleRight
		var middleTop = game.add.sprite(60,80,'wallH1',0,this.walls);
		middleTop.scale.setTo(0.7,1);//middleTop
		var middleBottom = game.add.sprite(110,230,'wallH1',0,this.walls);
		middleBottom.scale.setTo(0.7,1);//middleBottom
		
		//Make walls Immovable
		this.walls.setAll('body.immovable',true);	
	},
	create: function(){
    game.stage.backgroundColor = '#5d6d7e';
	game.physics.startSystem(Phaser.Physics.ARCADE);
    
        //player
        this.player = game.add.sprite(game.width/2, game.height/170, 'player');
		this.player.anchor.setTo(12, -7);
		game.physics.arcade.enable(this.player);
        this.cursor = game.input.keyboard.createCursorKeys(); 
        this.player.body.gravity.y = 210 //gravity


		//coins
		this.coin = game.add.sprite(60,140, 'coin');
		game.physics.arcade.enable(this.coin);
        this.coin.anchor.setTo(0.5,0.5);	
        
        //score labelling
		this.scoreLabel = game.add.text(20,20,'Ruby: 0',{font: '20px Arial', fill: 'Yellow'});
        this.score = 0;
        
        //Walls 
        this.createWorld();

        //Pause		
		this.pauseButton = this.add.button(490, 1, 'button-pause', this.managePause, this);
		this.pauseButton.anchor.set(1,0);
		this.pauseButton.input.useHandCursor = true;

		//Sound	
		this.jumpAudio = game.add.audio('audio-jump');
		this.coinAudio = game.add.audio('audio-coin');
		this.music = game.add.audio('music');
		this.music.loop = true;
        this.music.play();

        //Enemy
        this.enemies = game.add.group();
		this.enemies.enableBody = true;
		this.enemies.createMultiple(2, 'enemy');
		game.time.events.loop(2200, this.addEnemy,this);
	},	
	managePause: function() {
		this.game.paused = true; //Pause
		var pausedText = this.add.text(250, 250, "Game paused, Click anywhere to continue.",{font: '16px Arial', fill: 'white'}, this.fontMessage);
		pausedText.anchor.set(0.5, 10);
		this.input.onDown.add(function(){
			pausedText.destroy(); //Play
			this.game.paused = false;
		}, this);
	
	},
	takeCoin: function(player,coin){
		this.coin.scale.setTo(0,0); //Coin Tween
        game.add.tween(this.coin.scale).to({x:1, y:1}, 500).start();

		this.score +=1;
		this.scoreLabel.text = 'Ruby: ' + this.score;
		
		this.coinAudio.play() //Coin Sound
        this.updateCoinPosition(); //New Position
	},	
	updateCoinPosition: function(){
		var coinPosition = [
		{x: 140, y: 60}, {x:470, y:200},  //Top
		{x: 60, y:140}, {x:440, y:120} , {x:230, y:200}, //Middle
		{x: 130, y:300},  {x:370, y:300} //Bottom
		
		];
		for (var i = 0;  i<coinPosition.length; i++){
			if(coinPosition[i].x == this.coin.x){
				coinPosition.splice(i,1);
			}
		}
	var newPosition = game.rnd.pick(coinPosition);
	
	this.coin.reset(newPosition.x,newPosition.y);
		
		
	},	
    movePlayer: function(){
		if(this.cursor.left.isDown){
			this.player.body.velocity.x = -200; //Left
		} else if(this.cursor.right.isDown){
			this.player.body.velocity.x = 200; //Right
		} else{
			this.player.body.velocity.x=0;
		}
		
		if(this.cursor.up.isDown && this.player.body.touching.down){
			this.player.body.velocity.y = -200; //Jump
			this.jumpAudio.play(); //Jump Sound
		
		}
		
	
	},
	addEnemy: function(){
		var enemy = this.enemies.getFirstDead();

		enemy.anchor.setTo(0.8, 1);
		enemy.reset(game.width/2, 0);

		
		enemy.body.gravity.y = 300;
		enemy.body.velocity.x = 100 * game.rnd.pick ([-1,1]);
		enemy.body.bounce.x = 1;
		enemy.checkWorldBounds = true;
		enemy.outOfBoundsKill = true;
		
	},
	playerDie: function(){
		this.player.kill();
	    this.music.stop()
	    alert("Game Over!  Rubbies Collected:" + this.score + "  ||  Press Okay to Play Again!?");		
		game.state.start('main');
	
	},
	update: function(){
	game.physics.arcade.collide(this.player,this.walls);
	this.movePlayer(); //Cursor
	if(!this.player.inWorld){
    this.playerDie();
	}
	game.physics.arcade.overlap(this.player,this.coin,this.takeCoin, null,this); 
	game.physics.arcade.collide(this.enemies, this.walls); 
	game.physics.arcade.overlap(this.player,this.enemies, this.playerDie, null, this);	
}


};
var game = new Phaser.Game(500,340,Phaser.AUTO,'batGame');
	game.state.add('main', mainState);
	game.state.start('main');	
		
	