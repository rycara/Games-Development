var mainState = {
	 
	  preload: function() {
	    game.load.image("player", "assests/player.png");
	    game.load.image('coin','assests/coin.png')
	  }, 

	  create: function() {
       game.stage.backgroundColor = '#3498db';
       game.physics.startSystem(Phaser.Physics.ARCADE);
       game.render.renderSession.roundPixels = true; 
       this.player = game.add.sprite(game.width/2, game.height/2,'player');
       this.player.anchor.setTo(0.5,0.5);
       game.physics.arcade.enable(this.player);
       this.player.body.gravity.y = 100
       this.cursor = game.input.keyboard.createCursorKeys();
       //display the coin
       this.coin = game.add.sprite(60,140, 'coin');
       // add arcade physics to the coin
       game.physics.arcade.enable(this.coin);
       //set the anchor point to its center
       this.coin.anchor.setTo(0.5,0.5);
       //display the score
       this.scoreLabel = game.add.text(30, 30, 'score:0',
        { font: '18px Arial', fill: '#ffffff' });
       //initialize the score variable
       this.score = 0;
       
     },


	 update:function() {
     this.movePlayer();
     game.physics.arcade.collide(this.player,this.walls);
     if (!this.player.inWorld) {
     	this.playerDie();
     	game.physics.arcade.overlap(this.player, this.coin, this.takeCoin,null, this);

     }

	 },
	 moveplayer:function() {
	 	if (this.cursor.left.isDown) {
	 		this.player.body.velocity.x = -200;
	 	}
	 	else if (this.cursor.right.isDown) {
	 		this.player.body.velocity.x = 200;
	 	}
	 	else {this.player.body.velocity.x = 0;
	 }
	 if (this.cursor.up.isDown && this.player.body.touching.down) {
	 	this.player.body.velocity.y =-320;
	  }
	  playerDie: function() {
	  	game.state.start("main");
	  }

	 },

	 takeCoin: function() {
     this.coin.kill();
     this.score += 5;
     this.scoreLabel.text = 'score:' + this.score;
	 },
	 game.add.tween(this.player.scale0.)
	 updateCoinPosition: function() {
	 	
	 }

}; 
var game = new Phaser.Game(500, 340, Phaser.AUTO, "gameDiv");

game.state.add('main', mainState); 
game.state.start ('main'); 